[![Build Status](https://travis-ci.org/twtiger/enigmail.svg?branch=master)](https://travis-ci.org/twtiger/enigmail)

Instructions for setting up the developer environment are in the provisioning directory.
