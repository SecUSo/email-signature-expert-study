module.exports = {
  "extends": "../../.eslintrc.js",

  "rules": {
    "no-constant-condition": 0,
    "no-invalid-this": 0
  }
};
