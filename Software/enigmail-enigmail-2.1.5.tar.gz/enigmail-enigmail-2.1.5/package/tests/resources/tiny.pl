#!/usr/bin/perl

printf("OK\n");
