/*
 * This Source Code Form is licensed under the GNU LGPL 3.0 license.
 *
 */

/*
 * This bit of code embeds the openPGP-JS libary. This is the part that is added after
 * the library code.
 */

  return window.openpgp;
}
