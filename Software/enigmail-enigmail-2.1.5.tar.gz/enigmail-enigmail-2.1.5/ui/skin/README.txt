classic:
- windows
  - one css for classic windows
  - one css for aero scheme
classic-seamokey:
- classic theme of seamonkey
modern:
- modern theme of seamonkey
tb-linux:
- linux
tb-mac:
- apple

for a new image:
- add it to all css files
  in the subdirs here
- add it to ../jar.mn file

Note:
- different schemes have different icon sizes

